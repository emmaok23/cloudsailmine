import { base44 } from './base44Client';


export const Service = base44.entities.Service;

export const Order = base44.entities.Order;



// auth sdk:
export const User = base44.auth;