
import React, { useState } from "react";
import { Order } from "@/api/entities";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CreditCard, Info, User, Lock, Globe, Server } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { createStripeCheckout } from "@/api/functions";

const linuxDistros = [
  "Ubuntu 22.04 LTS",
  "Ubuntu 20.04 LTS", 
  "Debian 12",
  "Debian 11",
  "CentOS 8",
  "AlmaLinux 9",
  "Rocky Linux 9",
  "Otro (requiere aprobación)"
];

export default function ServicePurchaseModal({ service, user, onClose }) {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    domain: generateRandomDomain(),
    customDomain: false,
    paymentMethod: 'stripe',
    osDistribution: service.type === 'vps' ? 'Ubuntu 22.04 LTS' : ''
  });

  function generateRandomDomain() {
    const adjectives = ['quick', 'smart', 'blue', 'green', 'fast', 'cool', 'new', 'bright'];
    const nouns = ['site', 'web', 'app', 'host', 'server', 'cloud', 'tech', 'pro'];
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];
    return `${adj}-${noun}-${Math.floor(Math.random() * 1000)}`;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const config = {
        username: formData.username || 'admin',
        password: formData.password || generatePassword(),
        ...(service.type === 'vps' && { osDistribution: formData.osDistribution })
      };

      const orderData = {
        service_id: service.id,
        service_type: service.type,
        total_amount: service.price,
        payment_method: formData.paymentMethod,
        domain: formData.customDomain ? formData.domain : `${formData.domain}.pox.pro-eurtec.com`,
        custom_domain: formData.customDomain,
        config: config,
        status: formData.paymentMethod === 'stripe' ? 'pending_payment' : 'pending_approval'
      };

      const order = await Order.create(orderData);
      
      if (formData.paymentMethod === 'stripe') {
        // Redirigir a Stripe Checkout
        const { data } = await createStripeCheckout({ orderId: order.id });
        if (data.checkout_url) {
          window.location.href = data.checkout_url;
          return; // Stop further execution as we are redirecting
        }
      }
      
      onClose();
      navigate(createPageUrl(`MyOrders?highlight=${order.id}`));
      
    } catch (error) {
      console.error("Error creating order:", error);
      alert("Error al crear el pedido. Por favor, inténtalo de nuevo.");
    }
    
    setIsLoading(false);
  };

  const generatePassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-2xl">
            {service.type === 'hosting' ? <Globe className="w-6 h-6" /> : <Server className="w-6 h-6" />}
            Contratar {service.name}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Service Summary */}
          <div className="bg-slate-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Resumen del servicio:</h3>
            <div className="flex justify-between items-center">
              <span>{service.name}</span>
              <span className="font-bold">€{service.price}/mes</span>
            </div>
          </div>

          {/* Domain Configuration */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="domain">Dominio</Label>
              <div className="flex gap-2 mt-1">
                <Input
                  id="domain"
                  value={formData.domain}
                  onChange={(e) => setFormData({...formData, domain: e.target.value})}
                  placeholder="mi-sitio-web"
                />
                {!formData.customDomain && (
                  <span className="flex items-center px-3 bg-slate-100 border rounded-md text-slate-600">
                    .pox.pro-eurtec.com
                  </span>
                )}
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="customDomain"
                checked={formData.customDomain}
                onChange={(e) => setFormData({...formData, customDomain: e.target.checked})}
                className="rounded"
              />
              <Label htmlFor="customDomain">Usar dominio personalizado</Label>
            </div>
            
            {formData.customDomain && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Los dominios personalizados requieren aprobación del administrador. 
                  Se te contactará con instrucciones y costos adicionales.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Access Credentials */}
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <User className="w-5 h-5" />
              Credenciales de Acceso
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="username">Usuario (opcional)</Label>
                <Input
                  id="username"
                  value={formData.username}
                  onChange={(e) => setFormData({...formData, username: e.target.value})}
                  placeholder="admin"
                />
                <p className="text-sm text-slate-500 mt-1">Por defecto: admin</p>
              </div>
              
              <div>
                <Label htmlFor="password">Contraseña (opcional)</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  placeholder="Generada automáticamente"
                />
                <p className="text-sm text-slate-500 mt-1">Se genera automáticamente si no se especifica</p>
              </div>
            </div>
          </div>

          {/* VPS OS Selection */}
          {service.type === 'vps' && (
            <div>
              <Label htmlFor="osDistribution">Sistema Operativo</Label>
              <Select value={formData.osDistribution} onValueChange={(value) => setFormData({...formData, osDistribution: value})}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Selecciona distribución" />
                </SelectTrigger>
                <SelectContent>
                  {linuxDistros.map((distro) => (
                    <SelectItem key={distro} value={distro}>
                      {distro}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {formData.osDistribution === 'Otro (requiere aprobación)' && (
                <Alert className="mt-2">
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Las distribuciones personalizadas requieren aprobación del administrador.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}

          {/* Payment Method */}
          <div>
            <Label>Método de Pago</Label>
            <RadioGroup 
              value={formData.paymentMethod} 
              onValueChange={(value) => setFormData({...formData, paymentMethod: value})}
              className="mt-2"
            >
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="stripe" id="stripe" />
                <Label htmlFor="stripe" className="flex items-center gap-2 cursor-pointer">
                  <CreditCard className="w-4 h-4" />
                  Tarjeta de Crédito (Stripe)
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="manual" id="manual" />
                <Label htmlFor="manual" className="cursor-pointer">
                  Pago Manual (Contacto con administrador)
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              {isLoading ? 'Procesando...' : `Proceder al Pago - €${service.price}`}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
