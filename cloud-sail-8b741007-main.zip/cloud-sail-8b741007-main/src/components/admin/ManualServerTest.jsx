import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  Play, 
  CheckCircle, 
  XCircle, 
  Clock,
  Terminal,
  Server,
  Activity,
  AlertTriangle,
  Copy
} from "lucide-react";
import { testServerConnection } from "@/api/functions";

export default function ManualServerTest() {
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [customPayload, setCustomPayload] = useState(JSON.stringify({
    service_type: "hosting",
    order_data: {
      username: "test-user",
      password: "test-password-123",
      domain: "test-manual.pox.pro-eurtec.com",
      custom_domain: false
    }
  }, null, 2));

  const testTypes = [
    {
      id: 'health',
      name: 'Health Check',
      description: 'Verificar conectividad básica',
      icon: Activity,
      color: 'bg-green-500'
    },
    {
      id: 'deploy',
      name: 'Deploy Test',
      description: 'Probar endpoint de deployment',
      icon: Server,
      color: 'bg-blue-500'
    },
    {
      id: 'logs',
      name: 'Get Logs',
      description: 'Obtener logs del servidor',
      icon: Terminal,
      color: 'bg-purple-500'
    },
    {
      id: 'containers',
      name: 'List Containers',
      description: 'Listar contenedores activos',
      icon: Server,
      color: 'bg-orange-500'
    }
  ];

  const runTest = async (testType) => {
    setIsLoading(true);
    
    try {
      let payload = null;
      if (testType === 'deploy') {
        try {
          payload = JSON.parse(customPayload);
        } catch (parseError) {
          alert('Error en el JSON del payload: ' + parseError.message);
          setIsLoading(false);
          return;
        }
      }

      const { data } = await testServerConnection({ 
        testType: testType,
        payload: payload 
      });
      
      const newResult = {
        id: Date.now(),
        testType: testType,
        timestamp: new Date().toLocaleString(),
        ...data
      };
      
      setResults(prev => [newResult, ...prev].slice(0, 10)); // Mantener solo los últimos 10
      
    } catch (error) {
      console.error('Test error:', error);
      const errorResult = {
        id: Date.now(),
        testType: testType,
        timestamp: new Date().toLocaleString(),
        success: false,
        error: error.message,
        details: 'Error ejecutando el test'
      };
      setResults(prev => [errorResult, ...prev].slice(0, 10));
    }
    
    setIsLoading(false);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  const getResultIcon = (result) => {
    if (result.success) return CheckCircle;
    return XCircle;
  };

  const getResultColor = (result) => {
    if (result.success) return 'text-green-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <Terminal className="w-6 h-6 text-blue-600" />
          Test Manual del Servidor
        </h2>
      </div>

      {/* Test Buttons */}
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Ejecutar Tests</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {testTypes.map((test) => {
              const TestIcon = test.icon;
              return (
                <Button
                  key={test.id}
                  onClick={() => runTest(test.id)}
                  disabled={isLoading}
                  className="h-auto p-4 flex flex-col items-center gap-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50"
                >
                  <div className={`w-8 h-8 ${test.color} rounded-lg flex items-center justify-center`}>
                    <TestIcon className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-center">
                    <p className="font-semibold text-sm">{test.name}</p>
                    <p className="text-xs text-slate-500">{test.description}</p>
                  </div>
                </Button>
              );
            })}
          </div>

          {/* Custom Deploy Payload */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">
              Payload para Deploy Test (JSON):
            </label>
            <Textarea
              value={customPayload}
              onChange={(e) => setCustomPayload(e.target.value)}
              className="font-mono text-sm"
              rows={8}
              placeholder="JSON payload para el test de deploy"
            />
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {results.length > 0 && (
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Resultados de Tests (Últimos 10)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {results.map((result) => {
                const ResultIcon = getResultIcon(result);
                return (
                  <div key={result.id} className="border rounded-lg p-4 bg-slate-50/50">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <ResultIcon className={`w-5 h-5 ${getResultColor(result)}`} />
                        <div>
                          <p className="font-semibold text-slate-900">{result.testType}</p>
                          <p className="text-sm text-slate-500">{result.timestamp}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={result.success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                          {result.success ? 'Éxito' : 'Error'}
                        </Badge>
                        {result.status_code && (
                          <Badge variant="outline">HTTP {result.status_code}</Badge>
                        )}
                      </div>
                    </div>

                    <div className="grid lg:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="font-medium text-slate-700 mb-2">Request Info:</p>
                        <div className="bg-white p-2 rounded text-xs font-mono">
                          <p><strong>Endpoint:</strong> {result.server_endpoint}</p>
                          <p><strong>Test:</strong> {result.testType}</p>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <p className="font-medium text-slate-700">Response:</p>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => copyToClipboard(JSON.stringify(result, null, 2))}
                            className="h-6 px-2 text-xs"
                          >
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="bg-white p-2 rounded max-h-32 overflow-y-auto">
                          {result.error ? (
                            <div className="text-red-600 text-xs">
                              <p><strong>Error:</strong> {result.error}</p>
                              {result.raw_response && (
                                <p className="mt-1"><strong>Raw:</strong> {result.raw_response}</p>
                              )}
                            </div>
                          ) : (
                            <pre className="text-xs text-slate-700">
                              {JSON.stringify(result.response, null, 2)}
                            </pre>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {isLoading && (
        <div className="flex items-center justify-center py-8">
          <div className="flex items-center gap-3">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
            <p className="text-slate-600">Ejecutando test...</p>
          </div>
        </div>
      )}
    </div>
  );
}