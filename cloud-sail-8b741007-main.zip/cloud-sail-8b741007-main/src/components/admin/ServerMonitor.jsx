import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Server, 
  Activity, 
  RefreshCw, 
  CheckCircle, 
  XCircle,
  Clock,
  Container,
  Terminal,
  Wifi,
  AlertTriangle
} from "lucide-react";
import { getServerStatus } from "@/api/functions";

export default function ServerMonitor() {
  const [serverData, setServerData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const fetchServerStatus = useCallback(async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);

    try {
      setError(null);
      const { data } = await getServerStatus();
      
      if (data.status === 'success') {
        setServerData(data);
      } else {
        setError(data.message || 'Error desconocido');
        console.error("Server monitor backend error:", data);
      }
    } catch (err) {
      console.error('Error fetching server status:', err);
      setError('No se puede conectar con el servidor o la solicitud falló.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [isRefreshing]);

  useEffect(() => {
    fetchServerStatus();
    
    const interval = setInterval(() => {
      if (autoRefresh) {
        fetchServerStatus();
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [autoRefresh, fetchServerStatus]);

  const getStatusColor = (status) => {
    return status === 'success' ? 'text-green-600' : 'text-red-600';
  };

  const getStatusIcon = (status) => {
    return status === 'success' ? CheckCircle : XCircle;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <Activity className="w-6 h-6 text-blue-600" />
          Monitor del Servidor
        </h2>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="autoRefresh"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="rounded"
            />
            <label htmlFor="autoRefresh" className="text-sm font-medium">
              Auto-actualizar (15s)
            </label>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => fetchServerStatus()}
            disabled={isRefreshing}
            className="flex items-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            Actualizar
          </Button>
        </div>
      </div>

      {/* Error State */}
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Error de conectividad:</strong> {error}
            {serverData?.server?.endpoint && (
              <div className="mt-2 text-sm">
                Endpoint: <code>{serverData.server.endpoint}</code>
              </div>
            )}
          </AlertDescription>
        </Alert>
      )}

      {/* Server Status */}
      {serverData && (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Server Health */}
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Server className="w-5 h-5" />
                Estado del Servidor
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                {React.createElement(getStatusIcon(serverData.status), {
                  className: `w-6 h-6 ${getStatusColor(serverData.status)}`
                })}
                <div>
                  <p className="font-semibold">
                    {serverData.status === 'success' ? 'En línea' : 'Desconectado'}
                  </p>
                  <p className="text-sm text-slate-500">
                    {serverData.server?.endpoint || 'Endpoint no configurado'}
                  </p>
                </div>
              </div>
              
              {serverData.server?.health && (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Última respuesta:</span>
                    <span className="font-mono text-xs">
                      {new Date(serverData.server.health.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Puerto:</span>
                    <Badge variant="outline">8009</Badge>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Containers Status */}
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Container className="w-5 h-5" />
                Contenedores Activos
              </CardTitle>
            </CardHeader>
            <CardContent>
              {serverData.containers?.length > 0 ? (
                <div className="space-y-3">
                  {serverData.containers.slice(0, 3).map((container, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                      <div>
                        <p className="font-medium text-sm">{container.name}</p>
                        <p className="text-xs text-slate-500">{container.image}</p>
                      </div>
                      <Badge 
                        className={
                          container.status === 'running' 
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-red-100 text-red-700'
                        }
                      >
                        {container.status}
                      </Badge>
                    </div>
                  ))}
                  {serverData.containers.length > 3 && (
                    <p className="text-sm text-slate-500 text-center">
                      +{serverData.containers.length - 3} más...
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-slate-500 text-center py-4">
                  No hay contenedores activos
                </p>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Wifi className="w-5 h-5" />
                Estadísticas Rápidas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="text-center p-2 bg-blue-50 rounded">
                  <p className="font-bold text-lg text-blue-600">
                    {serverData.containers?.length || 0}
                  </p>
                  <p className="text-slate-600">Contenedores</p>
                </div>
                <div className="text-center p-2 bg-green-50 rounded">
                  <p className="font-bold text-lg text-green-600">
                    {serverData.containers?.filter(c => c.status === 'running').length || 0}
                  </p>
                  <p className="text-slate-600">Ejecutándose</p>
                </div>
              </div>
              
              <div className="text-xs text-slate-500 text-center">
                Última actualización: <br />
                <span className="font-mono">
                  {new Date(serverData.timestamp).toLocaleString()}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Activity Logs */}
      {serverData?.logs && (
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Terminal className="w-5 h-5" />
              Logs de Actividad (Últimos 10)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {serverData.logs.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {serverData.logs.slice(-10).reverse().map((log, index) => (
                  <div key={index} className="flex items-start gap-3 p-2 bg-slate-50 rounded text-sm">
                    <Clock className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex justify-between items-start gap-2">
                        <span className="font-mono text-xs text-slate-500">
                          {log.timestamp}
                        </span>
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${
                            log.level === 'error' ? 'border-red-200 text-red-700' :
                            log.level === 'warning' ? 'border-yellow-200 text-yellow-700' :
                            'border-blue-200 text-blue-700'
                          }`}
                        >
                          {log.level}
                        </Badge>
                      </div>
                      <p className="text-slate-700 mt-1">{log.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-slate-500 text-center py-8">
                No hay logs disponibles
              </p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}