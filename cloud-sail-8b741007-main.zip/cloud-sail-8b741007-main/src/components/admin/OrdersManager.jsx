
import React from 'react';
import { Order } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  CheckCircle,
  Clock,
  Play,
  AlertTriangle,
  ExternalLink,
  User,
  Globe,
  Server
} from "lucide-react";
import { format } from "date-fns";
import { deployService } from "@/api/functions";

const statusConfig = {
  pending_payment: {
    label: 'Pendiente de Pago',
    color: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    icon: Clock,
    progress: 10
  },
  paid: {
    label: 'Pagado',
    color: 'bg-blue-100 text-blue-800 border-blue-200',
    icon: CheckCircle,
    progress: 30
  },
  pending_approval: {
    label: 'Pendiente de Aprobación',
    color: 'bg-orange-100 text-orange-800 border-orange-200',
    icon: Clock,
    progress: 40
  },
  approved: {
    label: 'Aprobado',
    color: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    icon: CheckCircle,
    progress: 60
  },
  deploying: {
    label: 'Implementando',
    color: 'bg-purple-100 text-purple-800 border-purple-200',
    icon: Server,
    progress: 80
  },
  active: {
    label: 'Activo',
    color: 'bg-green-100 text-green-800 border-green-200',
    icon: CheckCircle,
    progress: 100
  },
  failed: {
    label: 'Error',
    color: 'bg-red-100 text-red-800 border-red-200',
    icon: AlertTriangle,
    progress: 0
  },
  cancelled: {
    label: 'Cancelado',
    color: 'bg-gray-100 text-gray-800 border-gray-200',
    icon: AlertTriangle,
    progress: 0
  }
};

export default function OrdersManager({ orders, onOrderUpdate }) {
  const handleApproveOrder = async (orderId) => {
    try {
      console.log('Approving and IMMEDIATELY deploying order:', orderId);
      
      await Order.update(orderId, {
        status: 'approved',
        deployment_logs: ['Pedido aprobado por administrador. Iniciando implementación...']
      });
      
      console.log('Order status set to "approved", now calling deploy function...');
      
      // AHORA LLAMAMOS DIRECTAMENTE A LA IMPLEMENTACIÓN
      await handleDeployOrder(orderId);

    } catch (error) {
      console.error("Error in approve & deploy flow:", error);
      alert("Error al aprobar e implementar el pedido.");
      // Revertir a pendiente de aprobación si falla
      try {
        await Order.update(orderId, { status: 'pending_approval' });
      } catch (revertError) {
        console.error("Failed to revert order status:", revertError);
      }
      onOrderUpdate();
    }
  };

  const handleDeployOrder = async (orderId) => {
    try {
      console.log('=== STARTING MANUAL DEPLOYMENT ===');
      console.log('Order ID:', orderId);
      
      // Primero actualizar el estado a deploying
      await Order.update(orderId, {
        status: 'deploying',
        deployment_logs: ['Iniciando implementación manual...']
      });
      
      console.log('Order status updated to deploying');
      onOrderUpdate(); // Actualizar UI inmediatamente

      // Llamar a la función deployService
      console.log('Calling deployService function...');
      const { data, status } = await deployService({ orderId });
      
      console.log('DeployService response status:', status);
      console.log('DeployService response data:', data);

      if (status === 200 && data.status === 'success') {
        console.log('Deployment successful!');
        alert('Servicio implementado exitosamente');
      } else {
        console.error('Deployment failed:', data);
        alert(`Error en deployment: ${data.message || 'Error desconocido'}`);
      }

      // Actualizar la UI después del resultado
      setTimeout(() => {
        onOrderUpdate();
      }, 2000);

    } catch (error) {
      console.error('=== DEPLOYMENT ERROR ===');
      console.error('Error details:', error);
      
      // Marcar como fallido en caso de error
      try {
        await Order.update(orderId, {
          status: 'failed',
          deployment_logs: [
            'Iniciando implementación manual...',
            `Error crítico: ${error.message}`
          ]
        });
      } catch (updateError) {
        console.error('Failed to update order status after error:', updateError);
      }
      
      alert(`Error crítico al implementar: ${error.message}`);
      onOrderUpdate();
    }
  };

  const handleCancelOrder = async (orderId) => {
    if (confirm("¿Estás seguro de que quieres cancelar este pedido?")) {
      try {
        await Order.update(orderId, {
          status: 'cancelled',
          deployment_logs: ['Pedido cancelado por administrador']
        });
        onOrderUpdate();
      } catch (error) {
        console.error("Error cancelling order:", error);
        alert("Error al cancelar el pedido");
      }
    }
  };

  const pendingOrders = orders.filter(o =>
    ['pending_payment', 'pending_approval', 'paid'].includes(o.status)
  );

  const activeOrders = orders.filter(o =>
    ['approved', 'deploying', 'active'].includes(o.status)
  );

  return (
    <div className="space-y-6">
      {/* Pending Orders */}
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <Clock className="w-5 h-5 text-orange-500" />
            Pedidos Pendientes ({pendingOrders.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {pendingOrders.length === 0 ? (
            <p className="text-slate-500 text-center py-8">No hay pedidos pendientes</p>
          ) : (
            <div className="space-y-4">
              {pendingOrders.map(order => {
                const status = statusConfig[order.status];
                const StatusIcon = status?.icon || Clock;

                return (
                  <div key={order.id} className="border rounded-lg p-4 bg-slate-50/50">
                    <div className="flex flex-col lg:flex-row justify-between items-start gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Badge className={`${status?.color} border flex items-center gap-1`}>
                            <StatusIcon className="w-3 h-3" />
                            {status?.label}
                          </Badge>
                          <span className="text-sm text-slate-600">
                            #{order.id.slice(-8)}
                          </span>
                          <span className="text-sm text-slate-500">
                            {format(new Date(order.created_date), 'dd/MM/yyyy HH:mm')}
                          </span>
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="font-medium text-slate-700 flex items-center gap-1">
                              <User className="w-3 h-3" />
                              Cliente
                            </p>
                            <p className="text-slate-600">{order.created_by}</p>
                          </div>
                          <div>
                            <p className="font-medium text-slate-700 flex items-center gap-1">
                              <Globe className="w-3 h-3" />
                              Dominio
                            </p>
                            <p className="text-slate-600">{order.domain}</p>
                          </div>
                          <div>
                            <p className="font-medium text-slate-700">Precio</p>
                            <p className="text-slate-900 font-semibold">€{order.total_amount}</p>
                          </div>
                        </div>

                        <div className="mt-3">
                          <Progress value={status?.progress || 0} className="h-2" />
                        </div>
                      </div>

                      <div className="flex gap-2">
                        {order.status === 'pending_approval' && (
                          <Button
                            size="sm"
                            onClick={() => handleApproveOrder(order.id)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Aprobar y Implementar
                          </Button>
                        )}

                        {['paid', 'approved'].includes(order.status) && (
                          <Button
                            size="sm"
                            onClick={() => handleDeployOrder(order.id)}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            <Play className="w-4 h-4 mr-1" />
                            Implementar
                          </Button>
                        )}

                        {!['active', 'deploying'].includes(order.status) && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleCancelOrder(order.id)}
                            className="text-red-600 border-red-200 hover:bg-red-50"
                          >
                            Cancelar
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Active Orders */}
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <Server className="w-5 h-5 text-green-500" />
            Servicios Activos ({activeOrders.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {activeOrders.length === 0 ? (
            <p className="text-slate-500 text-center py-8">No hay servicios activos</p>
          ) : (
            <div className="space-y-4">
              {activeOrders.map(order => {
                const status = statusConfig[order.status];
                const StatusIcon = status?.icon || Server;

                return (
                  <div key={order.id} className="border rounded-lg p-4 bg-slate-50/50">
                    <div className="flex flex-col lg:flex-row justify-between items-start gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Badge className={`${status?.color} border flex items-center gap-1`}>
                            <StatusIcon className="w-3 h-3" />
                            {status?.label}
                          </Badge>
                          <span className="text-sm text-slate-600">
                            #{order.id.slice(-8)}
                          </span>
                        </div>

                        <div className="grid md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="font-medium text-slate-700">Cliente</p>
                            <p className="text-slate-600">{order.created_by}</p>
                          </div>
                          <div>
                            <p className="font-medium text-slate-700">Dominio</p>
                            <p className="text-slate-600">{order.domain}</p>
                          </div>
                          <div>
                            <p className="font-medium text-slate-700">Tipo</p>
                            <p className="text-slate-600">{order.service_type}</p>
                          </div>
                          <div>
                            <p className="font-medium text-slate-700">Precio</p>
                            <p className="text-slate-900 font-semibold">€{order.total_amount}/mes</p>
                          </div>
                        </div>

                        {order.credentials && order.status === 'active' && (
                          <div className="mt-3 p-2 bg-green-50 rounded text-xs">
                            <p className="text-green-700 font-medium">Credenciales generadas</p>
                            <p className="text-green-600">SSH: {order.credentials.ssh_host}:{order.credentials.ssh_port}</p>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2">
                        {order.status === 'active' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(`https://${order.domain}`, '_blank')}
                          >
                            <ExternalLink className="w-4 h-4 mr-1" />
                            Ver Servicio
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
