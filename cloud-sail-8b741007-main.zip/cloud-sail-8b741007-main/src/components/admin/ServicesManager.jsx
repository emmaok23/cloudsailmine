
import React, { useState } from 'react';
import { Service } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Server, Monitor } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function ServicesManager({ services, onServicesUpdate }) {
  const [showModal, setShowModal] = useState(false);
  const [editingService, setEditingService] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    type: 'hosting',
    description: '',
    price: 0,
    stripe_price_id: '', // Added stripe_price_id
    specs: {
      cpu: '',
      ram: '',
      storage: '',
      bandwidth: ''
    },
    features: [],
    active: true
  });

  const handleCreateEdit = (service = null) => {
    if (service) {
      setEditingService(service);
      setFormData({
        ...service,
        stripe_price_id: service.stripe_price_id || '', // Ensure stripe_price_id is set for existing services
        features: service.features || []
      });
    } else {
      setEditingService(null);
      setFormData({
        name: '',
        type: 'hosting',
        description: '',
        price: 0,
        stripe_price_id: '', // Default for new service
        specs: {
          cpu: '',
          ram: '',
          storage: '',
          bandwidth: ''
        },
        features: [],
        active: true
      });
    }
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingService) {
        await Service.update(editingService.id, formData);
      } else {
        await Service.create(formData);
      }
      setShowModal(false);
      onServicesUpdate();
    } catch (error) {
      console.error("Error saving service:", error);
      alert("Error al guardar el servicio");
    }
  };

  const handleDelete = async (serviceId) => {
    if (confirm("¿Estás seguro de que quieres eliminar este servicio?")) {
      try {
        await Service.delete(serviceId);
        onServicesUpdate();
      } catch (error) {
        console.error("Error deleting service:", error);
        alert("Error al eliminar el servicio");
      }
    }
  };

  const addFeature = () => {
    const feature = prompt("Agregar nueva característica:");
    if (feature) {
      setFormData({
        ...formData,
        features: [...formData.features, feature]
      });
    }
  };

  const removeFeature = (index) => {
    setFormData({
      ...formData,
      features: formData.features.filter((_, i) => i !== index)
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">Gestión de Servicios</h2>
        <Button onClick={() => handleCreateEdit()} className="bg-green-600 hover:bg-green-700">
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Servicio
        </Button>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {services.map(service => {
          const ServiceIcon = service.type === 'hosting' ? Monitor : Server;
          return (
            <Card key={service.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                      <ServiceIcon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{service.name}</CardTitle>
                      <Badge className={service.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                        {service.active ? 'Activo' : 'Inactivo'}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">€{service.price}</div>
                    <div className="text-slate-500 text-sm">por mes</div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <p className="text-slate-600 mb-4">{service.description}</p>
                
                {service.stripe_price_id && (
                    <div className="mb-4 text-sm bg-slate-100 p-2 rounded-md">
                        <p className="font-semibold text-slate-700">Stripe Price ID:</p>
                        <p className="font-mono text-slate-500 text-xs">{service.stripe_price_id}</p>
                    </div>
                )}
                
                {service.specs && (
                  <div className="grid grid-cols-2 gap-2 text-sm mb-4">
                    {service.specs.cpu && <p><strong>CPU:</strong> {service.specs.cpu}</p>}
                    {service.specs.ram && <p><strong>RAM:</strong> {service.specs.ram}</p>}
                    {service.specs.storage && <p><strong>Storage:</strong> {service.specs.storage}</p>}
                    {service.specs.bandwidth && <p><strong>Bandwidth:</strong> {service.specs.bandwidth}</p>}
                  </div>
                )}
                
                <div className="flex justify-end gap-2">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleCreateEdit(service)}
                  >
                    <Edit className="w-4 h-4 mr-1" />
                    Editar
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleDelete(service.id)}
                    className="text-red-600 border-red-200 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Eliminar
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Service Form Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingService ? 'Editar Servicio' : 'Nuevo Servicio'}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nombre del Servicio</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label htmlFor="type">Tipo</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hosting">WordPress Hosting</SelectItem>
                    <SelectItem value="vps">VPS Linux</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="price">Precio Mensual (€)</Label>
                    <Input
                        id="price"
                        type="number"
                        step="0.01"
                        value={formData.price}
                        onChange={(e) => setFormData({...formData, price: parseFloat(e.target.value)})}
                        required
                    />
                </div>
                <div>
                    <Label htmlFor="stripe_price_id">Stripe Price ID</Label>
                    <Input
                        id="stripe_price_id"
                        value={formData.stripe_price_id}
                        onChange={(e) => setFormData({...formData, stripe_price_id: e.target.value})}
                        placeholder="price_..."
                        required
                    />
                </div>
            </div>

            {/* Specifications */}
            <div>
              <Label>Especificaciones Técnicas</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                <Input
                  placeholder="CPU (ej: 2 vCores)"
                  value={formData.specs.cpu}
                  onChange={(e) => setFormData({...formData, specs: {...formData.specs, cpu: e.target.value}})}
                />
                <Input
                  placeholder="RAM (ej: 4GB DDR4)"
                  value={formData.specs.ram}
                  onChange={(e) => setFormData({...formData, specs: {...formData.specs, ram: e.target.value}})}
                />
                <Input
                  placeholder="Storage (ej: 50GB SSD)"
                  value={formData.specs.storage}
                  onChange={(e) => setFormData({...formData, specs: {...formData.specs, storage: e.target.value}})}
                />
                <Input
                  placeholder="Bandwidth (ej: 1TB/mes)"
                  value={formData.specs.bandwidth}
                  onChange={(e) => setFormData({...formData, specs: {...formData.specs, bandwidth: e.target.value}})}
                />
              </div>
            </div>

            {/* Features */}
            <div>
              <div className="flex justify-between items-center">
                <Label>Características Incluidas</Label>
                <Button type="button" size="sm" variant="outline" onClick={addFeature}>
                  <Plus className="w-4 h-4 mr-1" />
                  Agregar
                </Button>
              </div>
              <div className="space-y-2 mt-2">
                {formData.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      value={feature}
                      onChange={(e) => {
                        const newFeatures = [...formData.features];
                        newFeatures[index] = e.target.value;
                        setFormData({...formData, features: newFeatures});
                      }}
                    />
                    <Button 
                      type="button" 
                      size="sm" 
                      variant="outline"
                      onClick={() => removeFeature(index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="active"
                checked={formData.active}
                onChange={(e) => setFormData({...formData, active: e.target.checked})}
              />
              <Label htmlFor="active">Servicio activo para venta</Label>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setShowModal(false)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                {editingService ? 'Actualizar' : 'Crear'} Servicio
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
