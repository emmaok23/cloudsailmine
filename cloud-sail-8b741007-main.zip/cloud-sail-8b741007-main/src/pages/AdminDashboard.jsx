import React, { useState, useEffect, useCallback } from "react";
import { Order } from "@/api/entities";
import { Service } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Shield,
  DollarSign,
  Server,
  Users,
  CheckCircle,
  Clock,
  AlertTriangle,
  Play,
  Activity,
  Terminal
} from "lucide-react";
import OrdersManager from "../components/admin/OrdersManager";
import ServicesManager from "../components/admin/ServicesManager";
import StatsCards from "../components/admin/StatsCards";
import ServerMonitor from "../components/admin/ServerMonitor";
import ManualServerTest from "../components/admin/ManualServerTest";

export default function AdminDashboardPage() {
  const [user, setUser] = useState(null);
  const [orders, setOrders] = useState([]);
  const [services, setServices] = useState([]);
  const [stats, setStats] = useState({
    totalOrders: 0,
    pendingOrders: 0,
    activeServices: 0,
    monthlyRevenue: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  const loadData = useCallback(async () => {
    try {
      const [ordersData, servicesData] = await Promise.all([
        Order.list('-created_date'),
        Service.list()
      ]);

      setOrders(ordersData);
      setServices(servicesData);

      // Calculate stats
      const pendingCount = ordersData.filter(o =>
        ['pending_payment', 'pending_approval', 'paid'].includes(o.status)
      ).length;

      const activeCount = ordersData.filter(o => o.status === 'active').length;

      const currentMonth = new Date().getMonth();
      const monthlyRevenue = ordersData
        .filter(o => {
          const orderMonth = new Date(o.created_date).getMonth();
          return orderMonth === currentMonth && o.payment_status === 'completed';
        })
        .reduce((sum, o) => sum + o.total_amount, 0);

      setStats({
        totalOrders: ordersData.length,
        pendingOrders: pendingCount,
        activeServices: activeCount,
        monthlyRevenue
      });

    } catch (error) {
      console.error("Error loading admin data:", error);
    }
    setIsLoading(false);
  }, []);

  const checkAdminAccess = useCallback(async () => {
    try {
      const currentUser = await User.me();
      if (currentUser.role !== 'admin') {
        window.location.href = '/';
        return;
      }
      setUser(currentUser);
      await loadData();
    } catch (error) {
      window.location.href = '/';
    }
  }, [loadData]);

  useEffect(() => {
    checkAdminAccess();
  }, [checkAdminAccess]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Shield className="w-8 h-8 text-blue-600" />
          <div>
            <h1 className="text-4xl font-bold text-slate-900">Panel de Administración</h1>
            <p className="text-slate-600">Gestiona pedidos y servicios de la plataforma</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCards
            title="Total Pedidos"
            value={stats.totalOrders}
            icon={Server}
            bgColor="bg-blue-500"
            trend={`${stats.pendingOrders} pendientes`}
          />
          <StatsCards
            title="Servicios Activos"
            value={stats.activeServices}
            icon={CheckCircle}
            bgColor="bg-green-500"
            trend="Funcionando"
          />
          <StatsCards
            title="Ingresos del Mes"
            value={`€${stats.monthlyRevenue.toFixed(2)}`}
            icon={DollarSign}
            bgColor="bg-purple-500"
          />
          <StatsCards
            title="Pendientes"
            value={stats.pendingOrders}
            icon={Clock}
            bgColor="bg-orange-500"
            trend="Requieren atención"
          />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="orders" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-[800px]">
            <TabsTrigger value="orders" className="flex items-center gap-2">
              <Server className="w-4 h-4" />
              Pedidos
            </TabsTrigger>
            <TabsTrigger value="services" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Servicios
            </TabsTrigger>
            <TabsTrigger value="monitor" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Monitor
            </TabsTrigger>
            <TabsTrigger value="test" className="flex items-center gap-2">
              <Terminal className="w-4 h-4" />
              Test Manual
            </TabsTrigger>
          </TabsList>

          <TabsContent value="orders">
            <OrdersManager orders={orders} onOrderUpdate={loadData} />
          </TabsContent>

          <TabsContent value="services">
            <ServicesManager services={services} onServicesUpdate={loadData} />
          </TabsContent>

          <TabsContent value="monitor">
            <ServerMonitor />
          </TabsContent>

          <TabsContent value="test">
            <ManualServerTest />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}