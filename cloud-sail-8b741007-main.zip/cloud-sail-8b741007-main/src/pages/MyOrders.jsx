
import React, { useState, useEffect, useCallback } from "react";
import { Order } from "@/api/entities";
import { Service } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Server, 
  Globe,
  Key,
  ExternalLink,
  CreditCard,
  WifiOff, // Added
  RefreshCw // Added
} from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

const statusConfig = {
  pending_payment: { 
    label: 'Pendiente de Pago', 
    color: 'bg-yellow-100 text-yellow-800 border-yellow-200', 
    icon: CreditCard,
    progress: 10 
  },
  paid: { 
    label: 'Pagado', 
    color: 'bg-blue-100 text-blue-800 border-blue-200', 
    icon: CheckCircle,
    progress: 30 
  },
  pending_approval: { 
    label: 'Pendiente de Aprobación', 
    color: 'bg-orange-100 text-orange-800 border-orange-200', 
    icon: Clock,
    progress: 40 
  },
  approved: { 
    label: 'Aprobado', 
    color: 'bg-indigo-100 text-indigo-800 border-indigo-200', 
    icon: CheckCircle,
    progress: 60 
  },
  deploying: { 
    label: 'Implementando', 
    color: 'bg-purple-100 text-purple-800 border-purple-200', 
    icon: Server,
    progress: 80 
  },
  active: { 
    label: 'Activo', 
    color: 'bg-green-100 text-green-800 border-green-200', 
    icon: CheckCircle,
    progress: 100 
  },
  failed: { 
    label: 'Error', 
    color: 'bg-red-100 text-red-800 border-red-200', 
    icon: AlertCircle,
    progress: 0 
  },
  cancelled: { 
    label: 'Cancelado', 
    color: 'bg-gray-100 text-gray-800 border-gray-200', 
    icon: AlertCircle,
    progress: 0 
  }
};

export default function MyOrdersPage() {
  const [orders, setOrders] = useState([]);
  const [services, setServices] = useState({});
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null); // Added error state

  // Removed loadOrders as loadData will handle all data fetching

  const loadData = useCallback(async (isRefreshing = false) => {
    if (!isRefreshing) {
      setIsLoading(true);
      setError(null); // Clear previous errors when starting a new load
    }
    
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const [ordersData, servicesData] = await Promise.all([
        Order.filter({ created_by: currentUser.email }, '-created_date'),
        Service.list()
      ]);
      
      setOrders(ordersData);
      
      // Changed to reduce for creating servicesMap
      const servicesMap = servicesData.reduce((acc, service) => {
        acc[service.id] = service;
        return acc;
      }, {});
      setServices(servicesMap);
      
    } catch (err) { // Changed error to err for consistency
      console.error("Error loading data:", err);
      setError(err.message || "Ocurrió un error de red. Por favor, revisa tu conexión.");
    } finally {
      setIsLoading(false);
    }
  }, []); // No external dependencies for initial load

  useEffect(() => {
    loadData();
  }, [loadData]); // Effect depends on the memoized loadData function

  useEffect(() => {
    // Only set up interval if there are orders with statuses that might change
    const hasPendingOrders = orders.some(order => 
      ['paid', 'approved', 'deploying'].includes(order.status)
    );

    if (!hasPendingOrders) return; // If no pending orders, no need for auto-refresh
    
    // Auto refresh every 30 seconds for active deployments
    const interval = setInterval(() => {
      loadData(true); // Re-fetch data without showing loader (isRefreshing = true)
    }, 30000);

    return () => clearInterval(interval); // Clear interval on unmount or when dependencies change
  }, [orders, loadData]); // Effect depends on orders and memoized loadData

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center">
          <WifiOff className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-700 mb-2">Error de Conexión</h3>
          <p className="text-slate-500 mb-6 max-w-sm">
            {error} Por favor, revisa tu conexión a internet e inténtalo de nuevo.
          </p>
          <Button onClick={() => loadData()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Reintentar
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Mis Pedidos</h1>
          <p className="text-slate-600">
            Gestiona y monitorea el estado de tus servicios contratados
          </p>
        </div>

        {orders.length === 0 ? (
          <div className="text-center py-16">
            <Server className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-600 mb-2">
              No tienes pedidos aún
            </h3>
            <p className="text-slate-500 mb-6">
              Contrata tu primer servicio para comenzar
            </p>
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
              Ver Servicios
            </Button>
          </div>
        ) : (
          <div className="grid gap-6">
            {orders.map((order, index) => {
              const service = services[order.service_id];
              const status = statusConfig[order.status];
              const StatusIcon = status?.icon || Clock;

              return (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                    <CardHeader>
                      <div className="flex flex-col lg:flex-row justify-between items-start gap-4">
                        <div className="flex-1">
                          <CardTitle className="text-xl font-bold text-slate-900 mb-2">
                            {service?.name || 'Servicio'}
                          </CardTitle>
                          <div className="flex flex-wrap items-center gap-3">
                            <Badge className={`${status?.color} border flex items-center gap-1`}>
                              <StatusIcon className="w-3 h-3" />
                              {status?.label}
                            </Badge>
                            <span className="text-slate-500 text-sm">
                              Pedido #{order.id.slice(-8)}
                            </span>
                            <span className="text-slate-500 text-sm">
                              {format(new Date(order.created_date), 'dd/MM/yyyy HH:mm')}
                            </span>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="text-2xl font-bold text-slate-900">
                            €{order.total_amount}
                          </div>
                          <div className="text-slate-500 text-sm">
                            {order.payment_method === 'stripe' ? 'Tarjeta' : 'Manual'}
                          </div>
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="mt-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-slate-600">Progreso</span>
                          <span className="text-sm text-slate-500">{status?.progress || 0}%</span>
                        </div>
                        <Progress value={status?.progress || 0} className="h-2" />
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      {/* Service Details */}
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
                            <Globe className="w-4 h-4" />
                            Dominio
                          </h4>
                          <p className="text-slate-700">{order.domain}</p>
                          {order.custom_domain && (
                            <Badge variant="outline" className="mt-1">
                              Dominio personalizado
                            </Badge>
                          )}
                        </div>

                        {order.config && (
                          <div>
                            <h4 className="font-semibold text-slate-900 mb-2 flex items-center gap-2">
                              <Key className="w-4 h-4" />
                              Configuración
                            </h4>
                            <div className="text-slate-700 space-y-1">
                              <p>Usuario: {order.config.username}</p>
                              {order.config.osDistribution && (
                                <p>SO: {order.config.osDistribution}</p>
                              )}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Credentials (only if active) */}
                      {order.status === 'active' && order.credentials && (
                        <div className="bg-slate-50 p-4 rounded-lg">
                          <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                            <Key className="w-4 h-4" />
                            Credenciales de Acceso
                          </h4>
                          <div className="grid md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-slate-600">Usuario:</p>
                              <p className="font-mono bg-white px-2 py-1 rounded">
                                {order.credentials.username}
                              </p>
                            </div>
                            <div>
                              <p className="text-slate-600">Contraseña:</p>
                              <p className="font-mono bg-white px-2 py-1 rounded">
                                {order.credentials.password}
                              </p>
                            </div>
                            {order.credentials.ssh_host && (
                              <div>
                                <p className="text-slate-600">SSH:</p>
                                <p className="font-mono bg-white px-2 py-1 rounded">
                                  ssh {order.credentials.username}@{order.credentials.ssh_host}:{order.credentials.ssh_port}
                                </p>
                              </div>
                            )}
                            {order.credentials.admin_url && (
                              <div>
                                <p className="text-slate-600">Panel:</p>
                                <a 
                                  href={order.credentials.admin_url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-1 text-blue-600 hover:text-blue-800"
                                >
                                  Acceder al panel
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Status Messages */}
                      {order.status === 'pending_payment' && order.payment_method === 'stripe' && (
                        <div className="bg-yellow-50 p-4 rounded-lg">
                          <p className="text-yellow-800">
                            Pendiente de pago. El servicio se implementará automáticamente tras confirmar el pago.
                          </p>
                        </div>
                      )}

                      {order.status === 'pending_approval' && (
                        <div className="bg-orange-50 p-4 rounded-lg">
                          <p className="text-orange-800">
                            El administrador revisará tu pedido. Te contactaremos pronto con más detalles.
                          </p>
                        </div>
                      )}

                      {order.status === 'deploying' && (
                        <div className="bg-purple-50 p-4 rounded-lg">
                          <p className="text-purple-800">
                            Tu servicio se está implementando. Esto puede tomar unos minutos.
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
