import React, { useState, useEffect } from "react";
import { Service } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Server, Monitor, Cpu, HardDrive, Wifi } from "lucide-react";
import { motion } from "framer-motion";
import ServicePurchaseModal from "../components/services/ServicePurchaseModal";

export default function ServicesPage() {
  const [services, setServices] = useState([]);
  const [user, setUser] = useState(null);
  const [selectedService, setSelectedService] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [servicesData, userData] = await Promise.all([
        Service.filter({ active: true }),
        User.me().catch(() => null)
      ]);
      setServices(servicesData);
      setUser(userData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const getServiceIcon = (type) => {
    return type === 'hosting' ? Monitor : Server;
  };

  const handlePurchase = (service) => {
    if (!user) {
      User.login();
      return;
    }
    setSelectedService(service);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          
          className="text-center mb-12"
        >
          <h1 className="text-4xl lg:text-6xl font-bold text-slate-900 mb-6">
            Nuestros Servicios
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Hosting WordPress optimizado y VPS Linux configurables.
            Implementación automática y soporte premium incluido.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const ServiceIcon = getServiceIcon(service.type);
            return (
              <motion.div
                key={service.id}
                
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                
              >
                <Card className="h-full bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-indigo-50/30"></div>
                  
                  <CardHeader className="relative pb-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center">
                          <ServiceIcon className="w-8 h-8 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-2xl font-bold text-slate-900">
                            {service.name}
                          </CardTitle>
                          <Badge className={`mt-2 ${
                            service.type === 'hosting' 
                              ? 'bg-emerald-100 text-emerald-700 border-emerald-200' 
                              : 'bg-blue-100 text-blue-700 border-blue-200'
                          }`}>
                            {service.type === 'hosting' ? 'WordPress Hosting' : 'VPS Linux'}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold text-slate-900">
                          €{service.price}
                        </div>
                        <div className="text-slate-500 text-sm">por mes</div>
                      </div>
                    </div>
                    
                    <p className="text-slate-600 text-lg leading-relaxed">
                      {service.description}
                    </p>
                  </CardHeader>

                  <CardContent className="relative space-y-6">
                    {/* Specifications */}
                    {service.specs && (
                      <div className="grid grid-cols-2 gap-4">
                        {service.specs.cpu && (
                          <div className="flex items-center gap-3">
                            <Cpu className="w-5 h-5 text-blue-600" />
                            <span className="text-slate-700">{service.specs.cpu}</span>
                          </div>
                        )}
                        {service.specs.ram && (
                          <div className="flex items-center gap-3">
                            <Server className="w-5 h-5 text-blue-600" />
                            <span className="text-slate-700">{service.specs.ram}</span>
                          </div>
                        )}
                        {service.specs.storage && (
                          <div className="flex items-center gap-3">
                            <HardDrive className="w-5 h-5 text-blue-600" />
                            <span className="text-slate-700">{service.specs.storage}</span>
                          </div>
                        )}
                        {service.specs.bandwidth && (
                          <div className="flex items-center gap-3">
                            <Wifi className="w-5 h-5 text-blue-600" />
                            <span className="text-slate-700">{service.specs.bandwidth}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Features */}
                    {service.features && (
                      <div className="space-y-3">
                        <h4 className="font-semibold text-slate-900">Características incluidas:</h4>
                        <div className="space-y-2">
                          {service.features.map((feature, idx) => (
                            <div key={idx} className="flex items-center gap-3">
                              <CheckCircle className="w-5 h-5 text-emerald-600" />
                              <span className="text-slate-700">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>

                  <CardFooter className="relative pt-6">
                    <Button 
                      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-3 text-lg font-semibold"
                      onClick={() => handlePurchase(service)}
                    >
                      {user ? 'Contratar Servicio' : 'Iniciar Sesión para Contratar'}
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {selectedService && (
          <ServicePurchaseModal
            service={selectedService}
            user={user}
            onClose={() => setSelectedService(null)}
          />
        )}
      </div>
    </div>
  );
}