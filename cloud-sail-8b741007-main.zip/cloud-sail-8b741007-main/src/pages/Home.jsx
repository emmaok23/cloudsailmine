import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Server, 
  Shield, 
  Zap, 
  Clock, 
  CheckCircle, 
  ArrowRight,
  Globe,
  Database,
  Lock
} from "lucide-react";

export default function HomePage() {
  const features = [
    {
      icon: Zap,
      title: "Implementación Instantánea",
      description: "Tu servicio estará listo en minutos tras el pago confirmado"
    },
    {
      icon: Shield,
      title: "Seguridad Avanzada",
      description: "Acceso SSH seguro y aislamiento completo entre servicios"
    },
    {
      icon: Clock,
      title: "Disponibilidad 24/7",
      description: "Monitoreo continuo y soporte técnico especializado"
    },
    {
      icon: Globe,
      title: "Dominios Incluidos",
      description: "Subdominios gratuitos bajo pox.pro-eurtec.com"
    },
    {
      icon: Database,
      title: "Backups Automáticos",
      description: "Copias de seguridad diarias de todos tus datos"
    },
    {
      icon: Lock,
      title: "SSL Gratuito",
      description: "Certificados SSL automáticos para todos los sitios"
    }
  ];

  const stats = [
    { number: "99.9%", label: "Uptime" },
    { number: "<5min", label: "Tiempo de implementación" },
    { number: "24/7", label: "Soporte técnico" },
    { number: "SSL", label: "Incluido gratis" }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative px-6 py-20 lg:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-transparent to-indigo-600/5"></div>
        
        <div className="max-w-7xl mx-auto relative">
          <div className="text-center max-w-4xl mx-auto">
            <Badge className="mb-6 bg-blue-50 text-blue-700 border-blue-200">
              <Zap className="w-4 h-4 mr-2" />
              Hosting y VPS Premium
            </Badge>
            
            <h1 className="text-5xl lg:text-7xl font-bold text-slate-900 mb-8 leading-tight">
              Servicios de
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent"> Hosting</span>
              <br />
              de Nueva Generación
            </h1>
            
            <p className="text-xl text-slate-600 mb-12 leading-relaxed">
              Implementación automática, seguridad avanzada y rendimiento excepcional.
              <br />
              Todo lo que necesitas para llevar tu proyecto al siguiente nivel.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("Services")}>
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-4 text-lg">
                  Ver Servicios
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-2 border-slate-200 hover:border-slate-300 px-8 py-4 text-lg"
              >
                Conocer Más
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="px-6 py-16 bg-white/50 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl lg:text-5xl font-bold text-slate-900 mb-2">
                  {stat.number}
                </div>
                <div className="text-slate-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-6 py-20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
              ¿Por qué elegir HostingPro?
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Combinamos tecnología de vanguardia con un servicio excepcional
              para ofrecerte la mejor experiencia de hosting.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-xl font-bold text-slate-900">
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-6 py-20 bg-gradient-to-r from-blue-600 to-indigo-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            ¿Listo para comenzar?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Únete a cientos de desarrolladores que confían en HostingPro
            para sus proyectos más importantes.
          </p>
          <Link to={createPageUrl("Services")}>
            <Button size="lg" className="bg-white text-blue-600 hover:bg-slate-50 px-8 py-4 text-lg font-semibold">
              Explorar Servicios
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}