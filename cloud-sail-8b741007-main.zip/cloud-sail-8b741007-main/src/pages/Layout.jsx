
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { 
  Server, 
  ShoppingCart, 
  Settings, 
  LogOut, 
  User as UserIcon,
  Shield,
  Home
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      setUser(null);
    }
    setIsLoading(false);
  };

  const handleLogout = async () => {
    await User.logout();
    setUser(null);
  };

  const navigationItems = user ? [
    {
      title: "Servicios",
      url: createPageUrl("Services"),
      icon: Server,
    },
    {
      title: "Mis Pedidos",
      url: createPageUrl("MyOrders"),
      icon: ShoppingCart,
    },
    ...(user.role === 'admin' ? [
      {
        title: "Panel Admin",
        url: createPageUrl("AdminDashboard"),
        icon: Shield,
      }
    ] : [])
  ] : [
    {
      title: "Inicio",
      url: createPageUrl("Home"),
      icon: Home,
    },
    {
      title: "Servicios",
      url: createPageUrl("Services"),
      icon: Server,
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <style>{`
        :root {
          --sidebar-bg: rgba(255, 255, 255, 0.95);
          --sidebar-border: rgba(226, 232, 240, 0.8);
          --primary-blue: #2563eb;
          --primary-blue-light: #3b82f6;
        }
      `}</style>
      
      {user ? (
        <SidebarProvider>
          <div className="min-h-screen flex w-full">
            <Sidebar className="border-r border-slate-200/80 bg-white/95 backdrop-blur-sm">
              <SidebarHeader className="border-b border-slate-200/80 p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
                    <Server className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="font-bold text-slate-900 text-lg">HostingPro</h2>
                    <p className="text-xs text-slate-500">Servicios Premium</p>
                  </div>
                </div>
              </SidebarHeader>
              
              <SidebarContent className="p-4">
                <SidebarGroup>
                  <SidebarGroupLabel className="text-xs font-medium text-slate-500 uppercase tracking-wider px-2 py-2">
                    Navegación
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    <SidebarMenu>
                      {navigationItems.map((item) => (
                        <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton 
                            asChild 
                            className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-xl mb-2 ${
                              location.pathname === item.url ? 'bg-blue-50 text-blue-700 shadow-sm' : ''
                            }`}
                          >
                            <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                              <item.icon className="w-5 h-5" />
                              <span className="font-medium">{item.title}</span>
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      ))}
                    </SidebarMenu>
                  </SidebarGroupContent>
                </SidebarGroup>
              </SidebarContent>

              <SidebarFooter className="border-t border-slate-200/80 p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                      <UserIcon className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-slate-900 text-sm truncate">{user.full_name}</p>
                      <p className="text-xs text-slate-500 truncate">{user.email}</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleLogout}
                    className="hover:bg-red-50 hover:text-red-600 transition-colors duration-200"
                  >
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              </SidebarFooter>
            </Sidebar>

            <main className="flex-1 flex flex-col">
              <header className="bg-white/80 backdrop-blur-sm border-b border-slate-200/80 px-6 py-4 lg:hidden">
                <div className="flex items-center gap-4">
                  <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
                  <h1 className="text-xl font-bold text-slate-900">HostingPro</h1>
                </div>
              </header>

              <div className="flex-1">
                {children}
              </div>
            </main>
          </div>
        </SidebarProvider>
      ) : (
        <div className="min-h-screen">
          <nav className="bg-white/80 backdrop-blur-sm border-b border-slate-200/80 px-6 py-4">
            <div className="max-w-7xl mx-auto flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                  <Server className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-slate-900 text-xl">HostingPro</span>
              </div>
              
              <div className="flex items-center gap-6">
                {navigationItems.map((item) => (
                  <Link 
                    key={item.title}
                    to={item.url} 
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                      location.pathname === item.url 
                        ? 'bg-blue-50 text-blue-700' 
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    {item.title}
                  </Link>
                ))}
                <Button 
                  onClick={() => User.login()} 
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-6"
                >
                  Iniciar Sesión
                </Button>
              </div>
            </div>
          </nav>
          
          <main>
            {children}
          </main>
        </div>
      )}
    </div>
  );
}
